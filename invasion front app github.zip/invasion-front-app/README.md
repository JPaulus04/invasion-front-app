# Invasion Front Commander — iOS Build

## Setup (one time)

1. Create a GitHub account at github.com if you don't have one
2. Create a new PRIVATE repository called `invasion-front-app`
3. Upload all files from this folder to that repo

## Files to upload to GitHub

```
invasion-front-app/
├── www/
│   └── index.html          ← your game file (rename from invasion_front_commander_ios_v2.html)
├── package.json
├── capacitor.config.json
├── .github/
│   └── workflows/
│       └── build-ios.yml
└── .gitignore
```

## Secrets to add in GitHub (Settings → Secrets → Actions)

| Secret Name | Where to get it |
|---|---|
| CERTIFICATE_BASE64 | Export from Apple Developer → .p12 → base64 encode |
| CERTIFICATE_PASSWORD | Password you set when exporting .p12 |
| KEYCHAIN_PASSWORD | Any password you choose (e.g. "build123") |
| PROVISIONING_PROFILE_BASE64 | Download from Apple Developer → base64 encode |
| APPLE_TEAM_ID | Apple Developer account → Membership → Team ID |
| ASC_KEY_ID | App Store Connect → Users → Keys → + |
| ASC_ISSUER_ID | Same page as above |
| ASC_API_KEY | Download the .p8 file, base64 encode it |

## How to base64 encode on Windows

Open PowerShell:
```powershell
[Convert]::ToBase64String([IO.File]::ReadAllBytes("C:\path\to\your\file.p12"))
```
Copy the output and paste it as the secret value.

## Running the build

1. Go to your GitHub repo
2. Click Actions tab
3. Click "Build & Upload iOS IPA"
4. Click "Run workflow" → Run
5. Wait ~15 minutes
6. Check App Store Connect → your app → Builds tab
